package com.develou.compose_temas.theme

import androidx.compose.ui.graphics.Color

val Yellow500 = Color(0xFFFFEB3B)

val Blue200 = Color(0xFF81D4FA)
val Blue500 = Color(0xFF2196F3)
val Blue700 = Color(0xFF1976D2)