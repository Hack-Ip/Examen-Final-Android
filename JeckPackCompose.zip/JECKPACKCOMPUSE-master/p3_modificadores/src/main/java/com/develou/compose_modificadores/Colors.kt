package com.develou.compose_modificadores

import androidx.compose.ui.graphics.Color

val yellow = Color(0xFFFFF9C4)
val blue = Color(0xFFB3E5FC)
val red = Color(0xFFFFCDD2)
val green = Color(0xFFC8E6C9)