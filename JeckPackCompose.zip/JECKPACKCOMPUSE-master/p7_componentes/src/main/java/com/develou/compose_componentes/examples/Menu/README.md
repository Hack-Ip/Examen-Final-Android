
## Menus En Compose  

En este paquete encontrarás el código de todos los ejemplos de mi tutorial [Menus En Compose](https://www.develou.com/menus-en-compose/) de Develou.com.
Dentro del archivo MenusScreen.kt encontrarás los ejemplos que se estudian:  

1. Dropdown Menu Simple-> `TaskMenu()`
2. Dropdown Menu Items Personalizados -> `ImageMenu()`
3. Dropdown Menu Temificado -> `ThemedTaskMenu()`
4. Exposed Dropdown Menu Simple -> `PhoneNumberTypeMenu()`