## Scaffold En Jetpack Compose

En este paquete encontrarás el código de todos los ejemplos de mi
tutorial [Scaffold En Jetpack Compose](https://www.develou.com/scaffold-en-jetpack-compose/) de
Develou.com. Dentro del archivo ScaffoldScreen.kt encuentras los ejemplos que se estudian:

2. Añadir Top App Bar
3. Añadir Bottom App Bar
4. Mostrar Una Snackbar
5. Añadir Floating Action Button
6. Añadir Navigation Drawer
7. Contenido Del Scaffold