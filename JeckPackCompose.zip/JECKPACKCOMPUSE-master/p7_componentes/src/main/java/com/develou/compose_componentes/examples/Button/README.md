## Floating Action Button En Compose

En este paquete encontrarás el código de todos los ejemplos de mi tutorial [FloatingActionButton En Compose](https://www.develou.com/floating-action-button-en-compose/) de Develou.com.
Cada archivo Kotlin contiene las funciones componibles asociadas a cada sección del tutorial:

 1. Tipos de FAB -> `01_FABTypes.kt`
 2. Posicionar FAB En Scaffold -> `02_FABInScaffold.kt`
 3. Estilizar Botones -> `03_FABTheming.kt`