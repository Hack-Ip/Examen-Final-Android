## Listas En Compose

En este paquete encontrarás el código de todos los ejemplos de mi
tutorial [Listas En Compose](https://www.develou.com/listas-en-compose/) de Develou.com. Dentro del
archivo ListsScreen.kt encontrarás los ejemplos que se estudian:

1. Componentes Para Crear Listas -> `01_ListsComponents.kt`
2. Propiedades De LazyColumn -> `02_Properties.kt`
3. Gestos Sobre Listas -> `03_Gestures.kt`
4. Controles De Lista -> `04_ Controls.kt`
5. Cambiar El Tema De Una Lista -> `05_ThemingList.kt`