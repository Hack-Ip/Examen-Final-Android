
## RadioButtons En Compose  

En este paquete encontrarás el código de todos los ejemplos de mi tutorial [Switch En Compose](https://www.develou.com/switch-en-compose/) de Develou.com.
Cada archivo Kotlin contiene las funciones componibles asociadas a cada sección del tutorial:  

1. Crear Un Switch-> `01_SimpleSwitch.kt`
2. Añadir Etiqueta A Un Switch -> `02_LabelledSwitch.kt`
3. Deshabilitar Un Switch -> `03_DisabledSwitch.kt`
4. Cambiar Color De Un Switch -> `04_ColoredSwitch.kt`