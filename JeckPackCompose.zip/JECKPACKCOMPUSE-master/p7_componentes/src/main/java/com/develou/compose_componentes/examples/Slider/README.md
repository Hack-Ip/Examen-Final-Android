
## Sliders En Compose  

En este paquete encontrarás el código de todos los ejemplos de mi tutorial [Slider En Compose](https://www.develou.com/slider-en-compose/) de Develou.com.
Dentro del archivo SlidersScreen.kt encontrarás los seis ejemplos que se estudian:  

1. Slider Continuo-> `SimpleContinuousSlider()`
2. Slider Discreto -> `SimpleDiscreteSlider()`
3. Slider Con Doble Selección -> `SimpleRangeSlider()`
4. Slider Con Texto Lateral -> `ContinuousSliderWithValue()`
5. Slider Con TextField -> `DiscreteSliderWithTextField()`
6. Slider Coloreado -> `ColoredSlider()`