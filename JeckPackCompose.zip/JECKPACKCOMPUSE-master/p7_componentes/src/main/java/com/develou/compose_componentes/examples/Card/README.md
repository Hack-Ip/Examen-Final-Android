## Cards En Jetpack Compose

En este paquete encontrarás el código de todos los ejemplos de mi
tutorial [Cards En Jetpack Compose](https://www.develou.com/cards-en-jetpack-compose/) de
Develou.com. Dentro del archivo CardsScreen.kt encuentras los ejemplos que se estudian:

1. Tipos De Cards -> `01_CardTypes.kt.kt`
2. Estilizar Una Card -> `02_StylingCard.kt.kt`
3. Lista De Cards -> `03_CardList.kt.kt`
4. Cambiar Tema De Card -> `04_ThemingCard.kt.kt`