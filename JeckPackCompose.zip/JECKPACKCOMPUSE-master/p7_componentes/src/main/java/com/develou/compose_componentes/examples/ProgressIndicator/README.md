## Indicadores De Progreso En Compose

En este paquete encontrarás el código de todos los ejemplos de mi
tutorial [Indicadores De Progreso En Compose](https://www.develou.com/indicadores-de-progreso-en-compose/)
de Develou.com. Cada archivo Kotlin contiene las funciones componibles de los ejemplos expuestos:

1. LinearProgressIndicator determinado-> `DeterminedLinearProgress()`
2. LinearProgressIndicator indeterminado -> `UndeterminedLinearProgress()`
3. LinearProgressIndicator coloreado -> `ColoredLinearProgress()`
4. CircularProgressIndicator determinado -> `DeterminedCircularProgress()`
5. CircularProgressIndicator indeterminado -> `UndeterminedCircularProgress()`
6. CircularProgressIndicator coloreado -> `ColoredCircularProgress()`