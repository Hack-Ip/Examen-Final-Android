## TopAppBar En Jetpack Compose

En este paquete encontrarás el código de todos los ejemplos de mi
tutorial [TopAppBar En Jetpack Compose](https://www.develou.com/topappbar-en-jetpack-compose/) de
Develou.com. Dentro del archivo TopAppBarScreen.kt encuentras los ejemplos que se estudian:

1. Crear Una Top App Bar -> `01_Creation.kt`
2. Añadir Action Items -> `02_ActionItems.kt`
3. Crear Una Top App Bar Prominente ->`03_ProminentTopAppBar.kt`
4. Personalizar La TopAppBar -> `04_Styling.kt`
5. Tematizar TopAppBar -> `05_Theming.kt`